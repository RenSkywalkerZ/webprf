"use client"
import { useState, useEffect } from "react"
import { Clock, AlertTriangle } from "lucide-react"

interface CountdownTimerProps {
  expiresAt: string
  onExpire?: () => void
}

export function CountdownTimer({ expiresAt, onExpire }: CountdownTimerProps) {
  const [timeLeft, setTimeLeft] = useState<{
    minutes: number
    seconds: number
    isExpired: boolean
  }>({ minutes: 0, seconds: 0, isExpired: false })

  useEffect(() => {
    const calculateTimeLeft = () => {
      const now = new Date().getTime()
      const expiration = new Date(expiresAt).getTime()
      const difference = expiration - now

      if (difference <= 0) {
        setTimeLeft({ minutes: 0, seconds: 0, isExpired: true })
        if (onExpire) {
          onExpire()
        }
        return
      }

      const minutes = Math.floor(difference / (1000 * 60))
      const seconds = Math.floor((difference % (1000 * 60)) / 1000)

      setTimeLeft({ minutes, seconds, isExpired: false })
    }

    // Calculate immediately
    calculateTimeLeft()

    // Set up interval to update every second
    const interval = setInterval(calculateTimeLeft, 1000)

    return () => clearInterval(interval)
  }, [expiresAt, onExpire])

  if (timeLeft.isExpired) {
    return (
      <div className="flex items-center gap-2 text-red-400">
        <AlertTriangle className="w-4 h-4" />
        <span className="font-medium">Registration expired</span>
      </div>
    )
  }

  const isUrgent = timeLeft.minutes === 0 && timeLeft.seconds <= 60
  const totalMinutes = timeLeft.minutes
  const displaySeconds = timeLeft.seconds

  return (
    <div className={`flex items-center gap-2 ${isUrgent ? "text-red-400" : "text-orange-400"}`}>
      {isUrgent && <AlertTriangle className="w-4 h-4 animate-pulse" />}
      <Clock className="w-4 h-4" />
      <span className="font-medium">
        Please transfer before in: {totalMinutes.toString().padStart(2, "0")}:
        {displaySeconds.toString().padStart(2, "0")}
      </span>
    </div>
  )
}
